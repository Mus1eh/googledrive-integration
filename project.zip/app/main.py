from fastapi import FastAPI

app = FastAPI(
    title="Google Integration API",
    description="This API integrates with Google services.",
    version="1.0.0",
)
